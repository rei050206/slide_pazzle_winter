# HTML&CSSとJavascripだけで作ったスライドパズル
## 概要
- 基本に立ち返ってHTMLとCSSとピュアなJavascriptだけで作ったソースコード

- index.htmlファイルをブラウザで開くことでパズルで遊べます
<img width="940" alt="image" src="https://github.com/sktaz/slide_pazzle_winter/assets/49140916/b678949f-411a-4599-9573-f6a6981405c4">

## 使用したもの
* HTML
* CSS
* Javascript

## 最短ルートでの正解
※ 初期設定の`displayOrder = [1, 8, 2, 7, 4, 3, 6, 5, 9]`の場合での最短ルート

https://github.com/sktaz/slide_pazzle_winter/assets/49140916/1d8aa916-e4a6-4043-8df3-f12a99aa7b52

